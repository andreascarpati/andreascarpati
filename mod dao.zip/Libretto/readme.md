# Libretto Universitario

Vogliamo realizzare un'applicazione JavaFX che ci aiuti a tenere traccia degli esami nel nostro carico didattico e degli esami da noi superati.

Il programma deve permettere di:
 - inserire i dati di un nuovo esame (Codice, Titolo, Docente)
 - ricercare un esame inserito (ricercandolo per codice)
 - per l'esame appena ricercato, si deve poter:

     - inserire la data ed il voto conseguito
     - cancellare l'esame (solo se non � stato superato)

In ogni momento, occorre visualizare la media degli esami superati.